from flask import Flask, render_template, url_for, session, request

app = Flask(__name__)

@app.route('/')
def index():
	return render_template('index.html')

@app.route('/login')
def login():
	return render_template('login.html')

@app.route('/logout')
def logout():
	session.pop('username', None)
	return redirect(url_for('index'))

@app.route('/register')
def register():
	return render_template('register.html')

@app.errorhandler(404)
def not_found(error):
	return render_template('404.html'), 404